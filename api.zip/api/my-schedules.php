<?php
include("connection.php");
if(isset($_GET["ecno"])){
	$ecno=mysqli_real_escape_string($conn,$_GET["ecno"]);
	$date=date('Y-m-d');
	$statement="SELECT * FROM tblworkinghours WHERE fldemployee_id='$ecno' ORDER BY fldcheckin DESC";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$reports=array();
	while($report=mysqli_fetch_assoc($query)){
		$report['fldcheckin']=date('Y-m-d H:i:s',$report['fldcheckin']);
		if($report['fldcheckout']!=""){
			$report['fldcheckout']=date('Y-m-d H:i:s',$report['fldcheckout']);
		}
		$reports[]=$report;
	}
	echo json_encode($reports);
}
?>