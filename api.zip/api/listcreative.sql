-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2022 at 12:01 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sharpconsult`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `fldemployee_id` int(11) NOT NULL,
  `fldphone_no` varchar(20) DEFAULT NULL,
  `fldforename` varchar(20) DEFAULT NULL,
  `fldsurname` varchar(20) DEFAULT NULL,
  `fldrole` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`fldemployee_id`, `fldphone_no`, `fldforename`, `fldsurname`, `fldrole`, `fldpassword`) VALUES
(1, '081234567890', 'Admin', 'listcreative', 'Manager', '5f4dcc3b5aa765d61d8327deb882cf99'),
(2, '0712923278', 'List', 'creative', 'Builder', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `tbllocations`
--

CREATE TABLE `tbllocations` (
  `fldlocation_id` int(11) NOT NULL,
  `fldemployee_id` int(11) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL,
  `fldlatitude` varchar(20) DEFAULT NULL,
  `fldlongitude` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbllocations`
--

INSERT INTO `tbllocations` (`fldlocation_id`, `fldemployee_id`, `fldtimestamp`, `fldlatitude`, `fldlongitude`) VALUES
(1547, 1, '2019-08-30 11:23:35', '-19.5184151', '29.8384625'),
(1548, 1, '2019-08-30 11:23:49', '-19.5184151', '29.8384625'),
(1549, 2, '2019-08-30 11:24:45', '-19.5186394', '29.8382371'),
(1550, 1, '2019-08-30 11:26:28', '-19.5183182', '29.8383862'),
(1551, 1, '2019-08-30 11:32:37', '-19.5184616', '29.8382905'),
(1552, 1, '2019-08-30 11:32:47', '-19.5184616', '29.8382905'),
(1553, 1, '2019-08-30 11:33:23', '-19.5184282', '29.8383452'),
(1554, 1, '2019-08-30 11:33:37', '-19.5184282', '29.8383452');

-- --------------------------------------------------------

--
-- Table structure for table `tblworkinghours`
--

CREATE TABLE `tblworkinghours` (
  `fldid` int(11) NOT NULL,
  `fldemployee_id` int(11) DEFAULT NULL,
  `fldcheckin` varchar(20) DEFAULT NULL,
  `fldcheckout` varchar(20) DEFAULT NULL,
  `fldsummary` varchar(200) DEFAULT NULL,
  `fldhours` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblworkinghours`
--

INSERT INTO `tblworkinghours` (`fldid`, `fldemployee_id`, `fldcheckin`, `fldcheckout`, `fldsummary`, `fldhours`) VALUES
(9, 1, '1567119951', '1567143494', 'jkkj', '23543'),
(11, 2, '1567157056', '1567161397', 'jdsfjsh', '4341');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`fldemployee_id`),
  ADD UNIQUE KEY `fldphone_no` (`fldphone_no`);

--
-- Indexes for table `tbllocations`
--
ALTER TABLE `tbllocations`
  ADD PRIMARY KEY (`fldlocation_id`),
  ADD KEY `fldemployee_id` (`fldemployee_id`);

--
-- Indexes for table `tblworkinghours`
--
ALTER TABLE `tblworkinghours`
  ADD PRIMARY KEY (`fldid`),
  ADD KEY `fldemployee_id` (`fldemployee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `fldemployee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbllocations`
--
ALTER TABLE `tbllocations`
  MODIFY `fldlocation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1555;

--
-- AUTO_INCREMENT for table `tblworkinghours`
--
ALTER TABLE `tblworkinghours`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbllocations`
--
ALTER TABLE `tbllocations`
  ADD CONSTRAINT `tbllocations_ibfk_1` FOREIGN KEY (`fldemployee_id`) REFERENCES `tblemployees` (`fldemployee_id`);

--
-- Constraints for table `tblworkinghours`
--
ALTER TABLE `tblworkinghours`
  ADD CONSTRAINT `tblworkinghours_ibfk_1` FOREIGN KEY (`fldemployee_id`) REFERENCES `tblemployees` (`fldemployee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
