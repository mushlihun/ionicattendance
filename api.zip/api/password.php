<?php
    include("connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $request = json_decode($postdata);
            $phoneno =mysqli_real_escape_string($conn,$request->phoneno);
            $password =mysqli_real_escape_string($conn,$request->password);
            $verifypassword =mysqli_real_escape_string($conn,$request->verifypassword);
            if($password==$verifypassword){
                $statement="UPDATE tblemployees SET fldpassword=MD5('$password') WHERE fldphone_no='$phoneno'";
                $query=mysqli_query($conn,$statement) or die(error());
                $response=array("response"=>"success");
            }else{
                $response=array("response"=>"Password Mismatch!");
            }
        } else{
            $response=array("response"=>"Server Error!");
        }
        echo json_encode($response);
    }
    function error(){
        $response=array("response"=>"Server Error!");
        echo json_encode($response);
    }
?>