<?php
    include("connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $request = json_decode($postdata);
            $employee_id = mysqli_real_escape_string($conn,$request->employee_id);
            $latitude =mysqli_real_escape_string($conn,$request->lat);
            $longitude =mysqli_real_escape_string($conn,$request->lng);
            $time=date('Y-m-d H:i:s');
            $statement="INSERT INTO tbllocations(fldemployee_id,fldtimestamp,fldlatitude,fldlongitude) VALUES('$employee_id','$time','$latitude','$longitude')";
            $query=mysqli_query($conn,$statement) or die(error());
            $response=array("response"=>"success");

        } else{
            $response=array("response"=>"error");
        }
        echo json_encode($response);
    }
    function error(){
        $response=array("response"=>"error");
        echo json_encode($response);
    }
?>